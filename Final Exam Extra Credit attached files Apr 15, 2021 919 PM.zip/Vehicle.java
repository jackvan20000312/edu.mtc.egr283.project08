/**  Vehicle
 * Represents a vehicle
 */
public class Vehicle {

    private int bornTime;
    private char destination;

    /**
     *  Constructs a  Light-object with b bornTime and d destination
     */
    public Vehicle(int b, char d)
    {
    }

    /**
     * @return A String-representation of the vechile and its bornTime and destination
     */
    public String toString()
    {
        return null;
    }
}
